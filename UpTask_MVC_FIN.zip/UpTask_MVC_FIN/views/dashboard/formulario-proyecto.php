<div class="campo">
    <label for="proyecto">Nombre Proyecto</label>
    <input
        type="text"
        name="proyecto"
        id="proyecto"
        placeholder="Nombre del Proyecto"
    />
</div>