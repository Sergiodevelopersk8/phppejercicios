import './horas.js';
import './ponentes.js';
import './tags.js'
import './slider.js';
import './mapa.js';
import './registro.js';
import './regalos.js';