        </div>
    </div>
</div>

<?php
    $script = '<script src="build/js/app.js"></script>';
?>