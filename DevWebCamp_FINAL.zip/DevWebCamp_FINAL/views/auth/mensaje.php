<main class="auth">
    <h2 class="auth__heading"><?php echo $titulo; ?></h2>
    <p class="auth__texto">
        Es necesario confirmar tu cuenta, revisa tu bandeja de entrada para hacerlo.
    </p> 

</main>