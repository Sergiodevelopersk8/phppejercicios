<h2 class="dashboard__heading"><?php echo $titulo; ?></h2>

<div class="dashboard__grafica">
    <canvas id="regalos-grafica" width="400" height="400"></canvas>
</div>